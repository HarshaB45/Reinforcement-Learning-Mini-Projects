# -*- coding: utf-8 -*-
"""
Created on Sat Jun  7 10:28:35 2025

@author: hbiru
"""

import numpy as np
import gymnasium as gym
import pygame
# Write just ONE line of code below this comment to import DQN from stable baseline
from stable_baselines3 import DQN

def visualize_model_performance(model):
    env = gym.make('MountainCar-v0', render_mode='human')
    
    x, _ = env.reset()
    total_reward = 0
    terminated, truncated = False, False
    while not(terminated) and not(truncated):
        action, _ = model.predict(x)
        x, reward, terminated, truncated, _ = env.step(action)
        total_reward += reward
    
    print('Total reward = {}'.format(total_reward))
    env.close()
    # pygame.display.quit() # Use this line when the display screen is not going away


class Custom_Wrapper(gym.Wrapper):
    def __init__(self, env):
        super().__init__(env)
        
    
    def step(self, action):
        observation, reward, terminated, truncated, info = self.env.step(action)
        
        # Extract position and velocity from observation
        position = observation[0]  # Car's position along the track
        velocity = observation[1]  # Car's velocity
        
        position_reward = position * 10.0  # Strong reward for positive positions
        speed_reward = abs(velocity) * 60.0  # Higher multiplier

        # Component 3: Strong penalty for not reaching goal
        time_penalty = -0.5 # Reduced but still meaningful
        
        # Weighted combination - make speed most important
        modified_reward = (
            0.32 * position_reward +    # 20% weight on position
            0.5 * speed_reward +       # 60% weight on speed (build momentum!)
            0.18 * time_penalty         # 20% weight on time penalty
        )
        
        # If goal is reached, give a large bonus reward
        if terminated and position >= 0.5:
            modified_reward += 100.0  # Big bonus for reaching the goal
        # Debug print to see what's happening (remove later)
        if hasattr(self, 'step_count'):
            self.step_count += 1
        else:
            self.step_count = 1
            
        if self.step_count % 50 == 0:  # Print every 50 steps
            print(f"Step {self.step_count}: pos={position:.3f}, vel={velocity:.3f}, reward={modified_reward:.3f}")
        
        return observation, modified_reward, terminated, truncated, info

# Initiate the mountain car environment.
env = gym.make('MountainCar-v0')

# Write just one line of code below this comment to create a modified environment using Custom_Wrapper class.
wrapped_env = Custom_Wrapper(env)

# Write just TWO lines of code below this comment to train a DQN model for mountain car.
model = DQN(
    "MlpPolicy",
    wrapped_env,
    learning_rate=1e-2,             # a typical default LR
    buffer_size=100000,            # enough replay capacity
    learning_starts=500,          # let it collect some data first
    batch_size=64,                  # standard minibatch size
    tau=1.0,                        # hard update of the target network
    train_freq=4,                   # train every 4 steps
    target_update_interval=1000,   # update target network every 1k steps
    exploration_initial_eps=1.0,
    exploration_final_eps=0.05,     # anneal down to 0.05
    policy_kwargs=dict(
        net_arch=[64]           # two hidden layers of size 64
    ),
    verbose=1
)

model.learn(total_timesteps=100000, log_interval=4)

# Close the mountain car environment.
wrapped_env.close()

# Write just ONE line of code below to save the DQN model that you have trained.
# YOU HAVE TO SUBMIT THIS MODEL. THE NAME OF THE MODEL MUST BE MODEL2.
# THE MODEL THAT YOU SUBMIT MUST NOT EXCEED 1 MB. ELSE ZERO FOR SECTION 4.
model.save("model2")

# Write just ONE line of code below this comment to call visualize_model_performance in order to test the performance of the trained model
visualize_model_performance(model)
